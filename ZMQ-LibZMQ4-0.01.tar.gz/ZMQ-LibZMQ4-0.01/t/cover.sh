#!/bin/sh
cover -test -ignore_re '^(?:t|etc|modules)/' -gcov